class Student:
    def __init__(mysillyobject):
        mysillyobject.Fname = input('enter student Fname:')
        mysillyobject.Lname = input('\nenter student Lname:')
        mysillyobject.RegNo = input('\nenter student RegNo:')
        mysillyobject.Course = input('\nenter student Course:')
        mysillyobject.AverageMark = int(input('\nenter student AverageMark:'))

    def myFname(abc):
        return abc.Fname

    def myLname(abc):
        return abc.Lname

    def myRegNo(abc):
        return abc.RegNo

    def myCourse(abc):
        return abc.Course

    def myMark(abc):
        return str(abc.AverageMark)

def addRecord():
    f = open("Assignment.txt", "a")
    d = Student()
    f.write(d.myFname() + "," + d.myLname() + "," + d.myRegNo() + "," + d.myCourse() + "," + d.myMark()+"\n")
    f.close()

def delRecord():
    RNumber = input("Enter your registration number of the student record to be deleted: ")
    f = open("Assignment.txt", "r")
    for line in enumerate(f.read()):
        row=line.split(',')
        if RNumber == row[3]:
            del (line)
        else:
            print("The registration number does not exist.")

def viewRecord():
    f = open("Assignment.txt", "r")
    print(f.read())
    f.close()

print(
    "Chose what action you want to perform\nA   :Add student record\nD "
    "  :Delete student record\nV   :view all records\nQ   :Quit")

while True:
    Choice = input("Enter your choice: ")
    if Choice == "A":
        addRecord()
    elif Choice == "D":
        delRecord()
    elif Choice == "V":
        viewRecord()
    elif Choice == "Q":
        break
    else:
        print("Wrong input")
